package com.example.notification

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.example.ScheduleApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@RequiresApi(Build.VERSION_CODES.N)
class FlowQuickTileService : TileService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartListening() {
        super.onStartListening()
        serviceScope.launch {
            val container = (application as ScheduleApp).container
            val enabled = container.preferencesRepository.settings.first().courseReminderEnabled
            updateTileUi(enabled)
        }
    }

    override fun onClick() {
        super.onClick()
        serviceScope.launch {
            val container = (application as ScheduleApp).container
            val current = container.preferencesRepository.settings.first().courseReminderEnabled
            val next = !current
            container.preferencesRepository.setCourseReminderEnabled(next)
            updateTileUi(next)
            container.liveUpdateCoordinator.syncAll(
                nowMillis = System.currentTimeMillis(),
                forceAlert = false,
                rescheduleAlarms = true,
            )
        }
    }

    private fun updateTileUi(enabled: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (enabled) "课程流体云" else "提醒已暂停"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (enabled) "已开启" else "点击恢复"
        }
        tile.updateTile()
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
